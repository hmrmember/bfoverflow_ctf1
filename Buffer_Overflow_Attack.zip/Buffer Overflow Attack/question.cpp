#include <iostream>
using namespace std;
int main(void)
{
  int arr[10];
  int arr_num;
  int num,i;

   cout << "Enter the count of numbers? ";
   cin >> num; //this integer can cause the bufferoverflow via arr

  for (i = 0; i < num; i++) // if we put num more than 10, it will cause the bufferoverflow
  {
    cout << "Enter a number to be stored: ";
    cin >> arr_num;
    arr[i]= arr_num; // after 10th integer the 11th integer would try to be written in the 11th index of the array whose memory is not allocated and hence it will cause the bufferoverflow
  }
  return 0;
}
